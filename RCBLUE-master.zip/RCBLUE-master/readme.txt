---->RC BLUE App<----

A custom app made for Self Balancing Robot using MIT App Inventor 2.

--->How to Operate
Controls and help guide is rc_manual found above.

---->Code & Documentation
code and apk is listed above.
For documentation,consult RC BLUE App Documentation

--->Sample code
A sample code for using the functionality of App.
<------------------------------------------------------------------------------------>
For Self Balancing Robot Tutorial,visit-
snapowermakers.tumblr.com